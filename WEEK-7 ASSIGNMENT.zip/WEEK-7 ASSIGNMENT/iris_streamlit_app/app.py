# app.py

import streamlit as st
import numpy as np
import pickle
from sklearn.datasets import load_iris

# Load model
with open("model/iris_model.pkl", "rb") as f:
    model = pickle.load(f)

print("Model Parameters:\n", model.get_params())
print("Feature Importances:\n", model.feature_importances_)

# Load class names
iris = load_iris()
class_names = iris.target_names

# Title
st.title("🌸 Iris Flower Prediction App")
st.write("Enter flower measurements to predict its species.")

# Input sliders
sepal_length = st.slider("Sepal Length (cm)", 4.0, 8.0, 5.1)
sepal_width = st.slider("Sepal Width (cm)", 2.0, 4.5, 3.5)
petal_length = st.slider("Petal Length (cm)", 1.0, 7.0, 1.4)
petal_width = st.slider("Petal Width (cm)", 0.1, 2.5, 0.2)

# Predict button
if st.button("Predict"):
    input_data = np.array([[sepal_length, sepal_width, petal_length, petal_width]])
    prediction = model.predict(input_data)[0]
    probability = model.predict_proba(input_data)[0]

    st.success(f"✅ Predicted Species: {class_names[prediction].capitalize()}")
    st.write("📊 Prediction Probabilities:")
    st.bar_chart(probability)
