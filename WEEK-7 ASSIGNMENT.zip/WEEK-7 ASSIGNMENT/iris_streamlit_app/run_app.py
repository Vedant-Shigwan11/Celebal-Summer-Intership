# run_app.py

import os

# Runs the streamlit app
os.system("streamlit run app.py")
